function rfpipepictures()
  return
  {
    north =
    {
      filename = "__reverse-factory__/graphics/entity/pipe-north.png",
      priority = "extra-high",
      width = 41,
      height = 40,
      shift = {0.09375, 0.4375}
    },
    east =
    {
      filename = "__reverse-factory__/graphics/entity/pipe-east.png",
      priority = "extra-high",
      width = 41,
      height = 40,
      shift = {-0.71875, 0}
    },
    south =
    {
      filename = "__reverse-factory__/graphics/entity/pipe-south.png",
      priority = "extra-high",
      width = 41,
      height = 40,
      shift = {0.0625, -1}
    },
    west =
    {
      filename = "__reverse-factory__/graphics/entity/pipe-west.png",
      priority = "extra-high",
      width = 41,
      height = 40,
      shift = {0.78125, 0.03125}
    }
  }
end