
_G.data:extend({
	{
		type = "int-setting",
		name = "folk-fill-ammo-stack-size",
		setting_type = "runtime-per-user",
		default_value = 10,
		maximum_value = 100,
		minimum_value = 5,
	},
	{
		type = "int-setting",
		name = "folk-fill-fuel-stack-size",
		setting_type = "runtime-per-user",
		default_value = 100,
		maximum_value = 100,
		minimum_value = 5,
	},
})

