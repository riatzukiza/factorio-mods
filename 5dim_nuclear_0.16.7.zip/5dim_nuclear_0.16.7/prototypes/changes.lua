data.raw["assembling-machine"]["centrifuge"].fast_replaceable_group = "centrifuge"
data.raw["boiler"]["heat-exchanger"].fast_replaceable_group = "heat-exchanger"
data.raw["reactor"]["nuclear-reactor"].fast_replaceable_group = "nuclear-reactor"
