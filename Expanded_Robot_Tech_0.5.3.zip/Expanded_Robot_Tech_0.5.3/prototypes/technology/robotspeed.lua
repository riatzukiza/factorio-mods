data.raw["technology"]["worker-robots-speed-6"].max_level = settings.startup["ert_speed1"].value
data.raw["technology"]["worker-robots-speed-6"].unit = {count_formula = "(L-6)*1000"}

data:extend(
{
  {
    type = "technology",
    name = "worker-robots-speed-"..settings.startup["ert_speed1"].value + 1,
	icon_size = 128,
    icon = "__base__/graphics/technology/worker-robots-speed.png",
    effects =
    {
      {
        type = "worker-robot-speed",
        modifier = 0.65
      }
    },
    prerequisites = {"worker-robots-speed-6"},
    unit =
    {
      count_formula = "2^(L-6)*1000",
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        {"high-tech-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 60
    },
    max_level = "infinite",
    upgrade = true,
    order = "c-k-f-e"
  },
}  
 )