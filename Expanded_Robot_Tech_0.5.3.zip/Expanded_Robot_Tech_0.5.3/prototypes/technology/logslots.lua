data:extend({
   
  {
    type = "technology",
    name = "character-logistic-slots-7",
	icon_size = 128,
    icon = "__base__/graphics/technology/character-logistic-slots.png",
    effects =
    {
      {
        type = "character-logistic-slots",
        modifier = 6
      }
    },
    prerequisites = {"character-logistic-slots-6"},
    unit =
    {
      count_formula = "1000+(L-6)*500",
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        {"high-tech-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 60
    },
    max_level = settings.startup["ert_logslots1"].value,
    upgrade = true,
    order = "c-k-f-e"
  },
  }
  )