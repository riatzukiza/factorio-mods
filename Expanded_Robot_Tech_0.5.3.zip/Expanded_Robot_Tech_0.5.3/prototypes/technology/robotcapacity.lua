data:extend(
{
	{
		type = "technology",
		name = "worker-robots-storage-4",
		icon_size = 128,
		icon = "__base__/graphics/technology/worker-robots-storage.png",
		effects = {
		  {
			type = "worker-robot-storage",
			modifier = "1"
		  }
		},
		prerequisites = {
		  "worker-robots-storage-3"
		},
		unit = {
		  count_formula = "500+(L11-3.5)*200",
		  ingredients = {
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1},
			{"production-science-pack", 1},
			{"high-tech-science-pack", 1},
			{"space-science-pack", 1}
		  },
		  time = 60
		},
		max_level = settings.startup["ert_capacity1"].value,
		upgrade = "true",
		order = "c-k-g-c"
	  },
}  
)