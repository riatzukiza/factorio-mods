require("config")
--require("prototypes.technology.robotspeed")
require("prototypes.technology.robotcapacity")
require("prototypes.technology.logslots")
require("prototypes.technology.trashslots")

-- if settings.runtime-global.ert_speed then

	-- require("prototypes.technology.robotspeed")
-- end
-- if settings.runtime-global.ert_capacity then

	-- require("prototypes.technology.robotcapacity")
-- end
-- if settings.runtime-global.ert_logslots then

	-- require("prototypes.technology.logslots")
-- end
-- if settings.runtime-global.ert_trashslots then

	-- require("prototypes.technology.trashslots")
-- end
