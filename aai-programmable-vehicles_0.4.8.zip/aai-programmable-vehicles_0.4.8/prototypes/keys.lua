data:extend
{
    {
        type = "custom-input",
        name = "create-toggle-controller",
        key_sequence = "Y",
    },
}
