util = {}
util.table = {}
	

function util.inform(s)
	-- if gSettings.cache()["debugging"] == false then return false end
	local str = s
	if type(s) ~= "string" then
		if (type(s) == "table") then
			str = util.table.tostring(s)
		else
			str = tostring(s)
		end
	end
	game.surfaces.nauvis.print("[Accommodating Walls]:> "..str)
end

function util.table.val_to_str ( v )
	if "string" == type( v ) then
	  v = string.gsub( v, "\n", "\\n" )
	  if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
		return "'" .. v .. "'"
	  end
	  return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
	else
	  return "table" == type( v ) and util.table.tostring( v ) or
		tostring( v )
	end
  end
  
  function util.table.key_to_str ( k )
	if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
	  return k
	else
	  return "[" .. util.table.val_to_str( k ) .. "]"
	end
  end
  
  function util.table.tostring( tbl )
	local result, done = {}, {}
	for k, v in ipairs( tbl ) do
	  table.insert( result, util.table.val_to_str( v ) )
	  done[ k ] = true
	end
	for k, v in pairs( tbl ) do
	  if not done[ k ] then
		table.insert( result,
		  util.table.key_to_str( k ) .. " = " .. util.table.val_to_str( v ) )
	  end
	end
	return " { " .. table.concat( result, ", " ) .. " } "
  end

-- function util.setting_val(str)
-- 	local setCache = global["setting_cache"]
-- 	local cachedVal = setCache[str]
-- 	if (cachedVal~=nil) then return cachedVal end
	
-- 	local name="ammo_loader_"..str
-- 	local setting = settings.global[name]
-- 	if (setting == nil) then error("Ammo Loader: No setting by the name of "..str) end
-- 	local lstZeroIsInfinite = {ammo_loader_max_items_per_slot=true, ammo_loader_max_items_per_inventory=true, ammo_loader_chest_radius=true}
-- 	if (lstZeroIsInfinite[name] ~= nil) and (setting['value'] == 0) then
-- 		setCache[str] = math.huge
-- 		return math.huge
-- 	end
-- 	setCache[str] = setting['value']
-- 	return global["setting_cache"][str]
-- end

function util.table.clear(t)
	for k,v in pairs(t) do
		t[k] = nil
	end
end

function util.table.anyTableItem(t)
    for k,v in pairs(t) do
        return v
    end
end

function util.table.combineTables(tList)
    local result = {}
    for k, v in pairs(tList) do
        for k2,v2 in pairs(v) do
            if (tonumber(k2) ~= nil) then
                table.insert(result, v2)
            end
        end
    end
    return result
end

function util.table.isEmpty(t)
	for k,v in pairs(t) do
		if (v) then return false end
	end
	return true
end

function util.table.contains(t, val)
	for k,v in pairs(t) do
		if (v==val) then return true end
	end
	return false
end

function util.table.containsValue(t, val)
	for k,v in pairs(t) do
		if (v==val) then return true end
	end
	return false
end

function util.table.size(t)
	local count = 0
	for k,v in pairs(t) do
		count = count+1
	end
	return count
end

function util.nauvisFind(options)
	local res = game.surfaces.nauvis.find_entities_filtered(options)
	return res
end

function util.getBoxAroundPosition(pos, dist)
	-- local surface = game.surfaces.nauvis
	local x = pos.x
	local y = pos.y
	local lt = {x=x-dist, y=y-dist}
	local rb = {x=x+dist, y=y+dist}
	local bb = {left_top=lt, right_bottom=rb}
	return bb
end

function util.getDistance(pos1, pos2)
	local getAbsVal = math.abs
	local p1x = pos1.x or pos1[1]
	local p1y = pos1.y or pos1[2]
	local p2x = pos2.x or pos2[1]
	local p2y = pos2.y or pos2[2]
	-- local p1 = {x=p1x, y=p1y}
	-- local p2 = {x=p2x, y=p2y}
	local xDif = p2x-p1x
	local yDif = p2y-p1y
	local xDif2 = xDif*xDif
	local yDif2 = yDif*yDif
	local difSum = xDif2 + yDif2
	local dist = math.sqrt(difSum)
	return dist
end

function util.coordsMatch(pos1, pos2)
	local x1 = pos1.x; local x2 = pos2.x; local y1 = pos1.y; local y2 = pos2.y
	if (x1 == x2) and (y1 == y2) then return true end
	return false
end

util.table.combineLists = function (t1, t2)
	local result = {}
	for i=1, #t1 do
		local curVal = t1[i]
		result[#result+1] = curVal
	end
	for i=1, #t2 do
		local curVal = t2[i]
		result[#result+1] = curVal
	end
	return result
end

util.string = {}
function util.string.contains(str, test)
	if (str:find(test)) then return true end
	return false
end

-- return util