

TrackedWall = {}
function TrackedWall.trackedWalls()
	return global["tracked_walls_queue"]
end
function TrackedWall.xList()
	return global["tracked_walls_x"]
end
function TrackedWall.yList()
	return global["tracked_walls_y"]
end
function TrackedWall.addWallToLists(wallObj)
	local trackedList = TrackedWall.trackedWalls()
	local xList = TrackedWall.xList()
	-- local yList = TrackedWall.yList()
	local coords = wallObj.coords

	if (xList[coords.x] == nil) then xList[coords.x] = {} end
	-- if (yList[coords.y] == nil) then yList[coords.y] = Queue() end

	local yList = xList[coords.x]
	if (yList[coords.y] == nil) then yList[coords.y] = Queue() end
	-- local ySubList = yList[coords.y]

	yList[coords.y]:pushright(wallObj)
	-- xSubList[wallObj] = true
	-- ySubList[wallObj] = true
	-- trackedList:pushright(wallObj)
end

function TrackedWall.new(ent)
	if (ent==nil) or (not ent.valid) then return nil end

	local obj = {}
	-- obj.ent = ent
	obj.type = ent.type
	obj.name = ent.name
	obj.surfaceName = ent.surface.name
	obj.surfaceIndex = ent.surface.index
	obj.forceName = ent.force.name
	obj.x = math.floor(ent.position.x)
	obj.y = math.floor(ent.position.y)
	obj.trueX = ent.position.x
	obj.trueY = ent.position.y
	obj.position = {}
	obj.position.x = obj.x
	obj.position.y = obj.y
	obj.coords = obj.position
	obj.disabled = false
	obj.toBeDecon = false
	obj.health = ent.health

	return obj
end

function TrackedWall.getSurface(obj)
	local surfName = obj.surfaceName or "nauvis"
	local surf = game.surfaces[surfName]
	return surf
end
function TrackedWall.getEnt(obj)
	if (obj.disabled) then return nil end
	if (obj.ent == nil) or (not obj.ent.valid) then
		local surf = TrackedWall.getSurface(obj)
		local pos = {x=obj.trueX, y=obj.trueY}
		local found = surf.find_entity(obj.name, pos)
		obj.ent = found
	end
	return obj.ent
end
function TrackedWall.disable(obj, player_index)
-- inform("disabling")
	if obj.disabled then
		obj.playerIndex = player_index
		return false
	end
	local ent = TrackedWall.getEnt(obj)
	if (ent ~= nil) and (ent.valid) then
		obj.toBeDecon = ent.to_be_deconstructed(obj.forceName)
		obj.playerIndex = player_index
		obj.health = ent.health
		local event = {entity=ent}
		script.raise_event(defines.events.on_entity_died, event)
		ent.destroy()
		obj.ent = nil
		global["removed_walls"][obj] = true
		obj.disabled = true
		-- inform("destroyed wall")
		return true
	end
	return false
end
function TrackedWall.enable(obj)
	local surf = TrackedWall.getSurface(obj)
	local truePos = {obj.trueX, obj.trueY}
	local canPlace = surf.can_place_entity{name=obj.name, position=truePos, force=obj.forceName}
	if (canPlace) then
		obj.ent = surf.create_entity{name=obj.name, position=truePos, force=obj.forceName}
		if (obj.ent ~= nil) and (obj.ent.valid) then
			if (obj.toBeDecon) then obj.ent.order_deconstruction(obj.forceName) end
			obj.ent.health = obj.health
			local event = {created_entity=obj.ent, player_index=obj.playerIndex, stack={name=obj.name, count=1}}
			script.raise_event(defines.events.on_built_entity, event)
			global["removed_walls"][obj] = nil
			obj.disabled = false
			return true
		end
	else
		local player = game.players[obj.playerIndex]
		if (player == nil) or (not player.valid) then
			global["removed_walls"][obj] = nil
			obj.disabled = false
			return false
		end
		local distToPlayer = util.getDistance(game.players[obj.playerIndex].position, truePos)
		if (distToPlayer > maxDist) then
			global["removed_walls"][obj] = nil
			obj.disabled = false
			return false
		end
	end
	return false
end
function TrackedWall.valid(obj)
	local ent = TrackedWall.getEnt(obj)
	if (ent == nil) or (not ent.valid) then
		if (not obj.disabled) then
			return false
		end
	end
	return true
end