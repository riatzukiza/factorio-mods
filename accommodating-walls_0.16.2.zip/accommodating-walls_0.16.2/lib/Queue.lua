function Queue()

		local q = {first = 0, last = -1}
		q.entries = {}
		q.list = q.entries

		function q:pushleft (value)
			if (not value) then error("value cannot be nil") end
			local list = self:get_entries()
			self.first = self.first - 1
			list[self.first] = value
		end

		function q:pushright (value)
			if (not value) then error("value cannot be nil") end
			local list = self:get_entries()
			self.last = self.last + 1
			list[self.last] = value
		end

		function q:popleft ()
			local list = self:get_entries()
			if self:size() <= 0 then return nil end
			local value = list[self.first]
			list[self.first] = nil        -- to allow garbage collection
			self.first = self.first + 1
			return value
		end

		function q:popright ()
			local list = self:get_entries()
			if self:size() <= 0 then return nil end
			local value = list[self.last]
			list[self.last] = nil         -- to allow garbage collection
			self.last = self.last - 1
			return value
		end

		function q:peekleft ()
			local list = self:get_entries()
			if self:size() <= 0 then return nil end
			local value = list[self.first]
			return value
		end

		function q:peekright ()
			local list = self:get_entries()
			if self:size() <= 0 then return nil end
			local value = list[self.last]
			return value
		end
		
		-- function q:cycle()
		-- 	local size = self:getSize()
		-- 	for i=1, size do
		-- 		local cur = self:popleft()
		-- 		if (cur ~= nil) then
		-- 			self:pushright(cur)
		-- 			return cur
		-- 		end
		-- 	end
		-- 	return nil
		-- end

		function q:is_empty ()
			return (self:size() <= 0)
		end

		function q:size ()
			return (self.last - self.first)+1
		end
		
		function q:getSize()
			return (self.last - self.first)+1
		end
		
		function q:get_size()
			return (self.last - self.first)+1
		end

		function q:get_entries ()
			return self.entries
		end

	return q	
end