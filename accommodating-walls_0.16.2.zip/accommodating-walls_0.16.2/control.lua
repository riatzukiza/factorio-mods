require "util"
require "lib/Queue"
require "lib/TrackedWall"
-- require 'lib/stdlib/stdlib/log/logger'

-- LOGGER = Logger.new("ammo-loader", "fancylog", true, {log_ticks=true} )

inform = util.inform
maxDist = 2
gSettings = {}
gSettings.cache = function() return global["settings_cache"] end
gSettings.lstZeroIsInfinite = {}
gSettings.shortHandNames = {awalls_ticks_between_wall_checks="waitTicks", awalls_enabled="enabled"}
function gSettings.update()
	global["settings_cache"] = {}
	local c = gSettings.cache()
	local shortHandNames = gSettings.shortHandNames

	for k, v in pairs(settings.global) do
		local shortHand = shortHandNames[k]
		if (shortHand ~= nil) then
			c[shortHand] = v.value
		end
	end
end

local function getAdjacentWalls(player, dist)
	local mFloor = math.floor
	local result = {}
	local playerPos = player.position
	local playerPosX = mFloor(playerPos.x)
	local playerPosY = mFloor(playerPos.y)
	local playerForce = player.force.name
	local removedList = global["removed_walls"]
	local xList = TrackedWall.xList()
	-- local yList = TrackedWall.yList()
	local minX = playerPosX-dist
	local maxX = playerPosX+dist
	local minY = playerPosY-dist
	local maxY = playerPosY+dist

	for x=minX, maxX do
		local yList = xList[x]
		if (yList ~= nil) then
			for y=minY, maxY do
				local subQ = yList[y]
				if (subQ == nil) or (subQ:size() <= 0) then
					yList[y] = nil
				else
					for i=1, subQ:size() do
						local wallObj = subQ:popleft()
						if (wallObj ~= nil) then
							if TrackedWall.valid(wallObj) then
								subQ:pushright(wallObj)

								if (wallObj.forceName == playerForce) then
									result[#result+1] = wallObj
									-- local yVal = wallObj.coords.y
									-- if (yVal ~= nil) and (yVal <= maxY) and (yVal >= minY) then
									-- 	result[#result+1] = wallObj
									-- end
								end
							end
						end
					end
				end
			end
		end
	end
	
	return result
	-- local bb = util.getBoxAroundPosition(player.position, dist)
	-- -- inform(bb)
	-- local found = player.surface.find_entities_filtered{type="wall", force=player.force, area=bb}
	-- return found
end

local function on_tick(event)
	local gCache = gSettings.cache()
	local enabled = gCache.enabled
	local waitTicks = gCache["waitTicks"]
	if (not enabled) or (event.tick % waitTicks ~= 0) then return false end

	local rmList = {}

	--identify and disable walls
	for ind, player in pairs(game.players) do
		-- inform("checking player number: "..ind)
		local adjWalls = getAdjacentWalls(player, maxDist)
		if (#adjWalls > 0) then
			-- inform("walls were found")
			for ind, wallObj in pairs(adjWalls) do
				rmList[wallObj] = true
				TrackedWall.disable(wallObj, player.index)
			end
		end
	end
	-- re-enable walls out of range
	for curWall, t in pairs(global["removed_walls"]) do
		if (not rmList[curWall]) then
			TrackedWall.enable(curWall)
		end
	end
end

local function globalExistsOrCreate(name, val)
	if (global[name] == nil) then global[name] = val end
end

local function on_built(event)
	local ent = event.created_entity
	if (ent ~= nil) and (ent.valid) then
		if (ent.type == "wall") then
			TrackedWall.addWallToLists(TrackedWall.new(ent))
		end
	end
end

local function findAllWalls()
	local found = util.nauvisFind{type="wall"}
	for ind, ent in pairs(found) do
		on_built({created_entity=ent})
	end
end

local function setUpGlobals()
	global = {}
	globalExistsOrCreate("settings_cache", {})
	globalExistsOrCreate("removed_walls", {})
	globalExistsOrCreate("removed_walls_queue", Queue())
	globalExistsOrCreate("tracked_walls_x", {})
	globalExistsOrCreate("tracked_walls_y", {})
	globalExistsOrCreate("tracked_walls", {})
	globalExistsOrCreate("tracked_walls_queue", Queue())

	gSettings.update()
	findAllWalls()
end

local function on_replaced(new_entity, old_entity)

end

script.on_event(defines.events.on_built_entity, on_built)
script.on_event(defines.events.on_robot_built_entity, on_built)
script.on_event(defines.events.script_raised_built, on_built)
script.on_event(defines.events.on_tick, on_tick)
script.on_event(defines.events.on_runtime_mod_setting_changed, function(event)
	gSettings.update()
	if (not gSettings.cache().enabled) then
		for wallObj, t in pairs(global["removed_walls"]) do
			if (wallObj ~= nil) then
				TrackedWall.enable(wallObj)
			end
		end
	end
end)
script.on_configuration_changed(function()
	setUpGlobals()
 end)
 script.on_init	(function()
	setUpGlobals()
 end)
 
script.on_load(function()
 end)