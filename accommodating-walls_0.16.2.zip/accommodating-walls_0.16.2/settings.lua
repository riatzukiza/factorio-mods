data:extend{
    {
        type = "bool-setting",
        name = "awalls_enabled",
        setting_type = "runtime-global",
        default_value = true,
        order = "Accommodating[items]-a[bools]"
    },
	{
        type = "int-setting",
        name = "awalls_ticks_between_wall_checks",
        setting_type = "runtime-global",
        default_value = 20,
		minimum_value = 1,
		order = "Accommodating[items]-b[ints]-a[performance]"
    }
}