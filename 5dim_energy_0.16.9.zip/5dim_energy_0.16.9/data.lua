require("config")
--Changes
require("prototypes.changes")
--lamp
require("prototypes.lamp")
--small pump
require("prototypes.small-pump-2")
require("prototypes.small-pump-3")
--offshore pump
require("prototypes.offshore-pump-2")
require("prototypes.offshore-pump-3")
--Accumulator
require("prototypes.accumulator-2")
require("prototypes.accumulator-3")
--Boilers
require("prototypes.boilers-2")
require("prototypes.boilers-3")
--Pole
require("prototypes.pole-4")
require("prototypes.pole-5")
require("prototypes.pole-6")
--Solar
require("prototypes.solar-2")
require("prototypes.solar-3")
--Steam Engine
require("prototypes.steam-engine-2")
require("prototypes.steam-engine-3")
--Tech
require("prototypes.tech")
