data.raw["accumulator"]["accumulator"].fast_replaceable_group = "accumulator"
data.raw["solar-panel"]["solar-panel"].fast_replaceable_group = "solar-panel"
data.raw["offshore-pump"]["offshore-pump"].fast_replaceable_group = "offshore-pump"