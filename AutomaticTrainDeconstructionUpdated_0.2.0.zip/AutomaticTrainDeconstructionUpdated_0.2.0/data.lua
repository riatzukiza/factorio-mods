require("defines")

require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.technology")