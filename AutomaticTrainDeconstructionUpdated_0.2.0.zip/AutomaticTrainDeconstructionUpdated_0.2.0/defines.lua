AutomaticTrainDeployment_defines = {}

AutomaticTrainDeployment_defines.names = 
{
	entities = 
	{
		deleteStop = "AutomaticTrainDeployment-delete-stop"
	},
	items =
	{
		deleteStop = "AutomaticTrainDeployment-delete-stop"
	},
	recipes = 
	{
		deleteStop = "AutomaticTrainDeployment-delete-stop"
	},
	technology = "AutomaticTrainDeployment-technology"
}