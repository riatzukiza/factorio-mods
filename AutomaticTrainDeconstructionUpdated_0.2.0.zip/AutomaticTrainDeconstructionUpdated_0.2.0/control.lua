script.on_event(defines.events.on_train_changed_state, function (event) 
    local train = event.train
	if not train or train.state ~= defines.train_state.wait_station then return end
	local station = train.station
	if not station then return end
	if station.name ~= "AutomaticTrainDeployment-delete-stop" then return end
	local cars = train.carriages
	local locos = {}
	local wagons = {}
	local fluid_wagons = {}
	for _,car in pairs(cars) do
	    if car.name == "locomotive" then table.insert(locos,car) end
		if car.name == "cargo-wagon" then table.insert(wagons,car) end
		if car.name == "fluid-wagon" then table.insert(fluid_wagons,car) end
	end
	local fuels = {}
	for _,loco in pairs(locos) do
	    local fuel = loco.get_fuel_inventory().get_contents()
		for nam,amount in pairs(fuel) do
    		table.insert(fuels,{name = nam,count = amount})
		end
	end
	local solids = train.get_contents()
	local liquids = train.get_fluid_contents()
	local chests = {}
	local tanks = {}
	for _, ent in pairs (station.circuit_connected_entities.red) do
	    if ent.name == "steel-chest" or ent.name == "iron-chest" or ent.name == "wooden-chest" or ent.name == "logistic-chest-active-provider" or ent.name == "logistic-chest-passive-provider" or ent.name == "logistic-chest-storage" or ent.name == "logistic-chest-requester" then
		    table.insert(chests,ent)
		end
		if ent.name == "storage-tank" then
		    table.insert(tanks,ent)
		end
	end
	for _, ent in pairs (station.circuit_connected_entities.green) do
	    if ent.name == "steel-chest" or ent.name == "iron-chest" or ent.name == "wooden-chest" or ent.name == "logistic-chest-active-provider" or ent.name == "logistic-chest-passive-provider" or ent.name == "logistic-chest-storage" or ent.name == "logistic-chest-requester" then
		    table.insert(chests,ent)
		end
		if ent.name == "storage-tank" then
		    table.insert(tanks,ent)
		end
	end
	if #chests == 0 then game.print("You have not connected a chest with a wire to the deletion station. Not destroying train") end
	if #chests >= 1 then
	    local numLocos = 0
		local numWagons = 0
		local numFluids = 0
		local chest = chests[1]
	    for _,loco in pairs(locos) do
		    loco.destroy()
			numLocos = numLocos + 1
		end
		for _,wagon in pairs(wagons) do
		    wagon.destroy()
			numWagons = numWagons + 1
		end
		for _,fluid in pairs(fluid_wagons) do
		    fluid.destroy()
			numFluids = numFluids + 1
		end
		if numLocos >= 1 then chest.insert({name="locomotive",count=numLocos}) end
		if numWagons >= 1 then chest.insert({name="cargo-wagon",count=numWagons}) end
		if numFluids >= 1 then chest.insert({name="fluid-wagon",count=numFluids}) end
		if #fuels >= 1 then
            for _,fuel in pairs(fuels) do
			    chest.insert(fuel)
			end
		end
	end
end
)
