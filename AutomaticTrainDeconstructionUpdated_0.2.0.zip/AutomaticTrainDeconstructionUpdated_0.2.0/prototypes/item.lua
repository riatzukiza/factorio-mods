require("util")

--[[ {
    type = "item",
    name = "train-stop",
    icon = "__base__/graphics/icons/train-stop.png",
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-c[train-stop]",
    place_result = "train-stop",
    stack_size = 10
  },
--]]

local deleteStop = table.deepcopy(data.raw.item["train-stop"])
deleteStop.name = AutomaticTrainDeployment_defines.names.items.deleteStop
deleteStop.place_result = AutomaticTrainDeployment_defines.names.entities.deleteStop
deleteStop.order = "z-a"




data:extend({deleteStop})