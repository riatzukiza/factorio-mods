require("util")

local deleteStop = table.deepcopy(data.raw["train-stop"]["train-stop"])
deleteStop.name = AutomaticTrainDeployment_defines.names.entities.deleteStop
deleteStop.minable = {mining_time = 1, result = AutomaticTrainDeployment_defines.names.items.deleteStop}



data:extend({deleteStop})