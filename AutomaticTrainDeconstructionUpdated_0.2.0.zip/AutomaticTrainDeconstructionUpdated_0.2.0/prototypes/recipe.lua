require("util")

local deleteStop = table.deepcopy(data.raw.recipe["train-stop"])
deleteStop.name = AutomaticTrainDeployment_defines.names.recipes.deleteStop
deleteStop.result = AutomaticTrainDeployment_defines.names.items.deleteStop



data:extend({deleteStop})