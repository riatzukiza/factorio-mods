--Define if vehicles is installed
infiniteResearch = true --Default: True