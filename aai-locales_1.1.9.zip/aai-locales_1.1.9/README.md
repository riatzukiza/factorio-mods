# AAI Locales [Addon]
# XMKTP(Xagros's Mods Korean Translation Project)
=============
localization mod for AAI mods for Factorio. Feel free to contribute on [github](https://github.com/GimoXagros/aai-locales)!
If you can help me translate in another language, please contact me. Discussion and E-mail
-------------
팩토리오 모드 한글화 프로젝트입니다. 검수 및 번역 작업에 이상이 있을 시 쓰레드나 이메일로 연락 바랍니다.
>[Discussion](https://mods.factorio.com/mods/Xagros/aai-locales/discussion) and rlgh0925@naver.com

Thank you for downloaded this mod. (By.Xagros)
https://mods.factorio.com/ 이외의 사이트 배포는 불허합니다. 공유가 필요 할 시 사이트 링크로 대체해주세요.

*****

#Thanks to the contributers
>aspd199 (简体中文)
mumu1000 (le français)
gamestrust (Italiano)
maurojunior2011 (Português brasileiro)
berkut2123 (русский)
MrMirmur (русский)
Sharaj (русский)
*****

#Translations list
>简体中文
le français
Italiano
한국어
Português
Português brasileiro
русский

*****

##Supported mods [Korean standard]
>[AAI Industry](https://mods.factorio.com/mods/Earendel/aai-industry)
[AAI Programmable Structures](https://mods.factorio.com/mods/Earendel/aai-programmable-structures)
[AAI Programmable Vehicles](https://mods.factorio.com/mods/Earendel/aai-programmable-vehicles)
[AAI Signals](https://mods.factorio.com/mods/Earendel/aai-signals)
[AAI Vehicles: Chaingunner](https://mods.factorio.com/mods/Earendel/aai-vehicles-chaingunner)
[AAI Vehicles: Flame Tank](https://mods.factorio.com/mods/Earendel/aai-vehicles-flame-tank)
[AAI Vehicles: Flame Tumbler](https://mods.factorio.com/mods/Earendel/aai-vehicles-flame-tumbler)
[AAI Vehicles: Hauler](https://mods.factorio.com/mods/Earendel/aai-vehicles-hauler)
[AAI Vehicles: Laser Tank](https://mods.factorio.com/mods/Earendel/aai-vehicles-laser-tank)
[AAI Vehicles: Miner](https://mods.factorio.com/mods/Earendel/aai-vehicles-miner)
[AAI Vehicles: Warden](https://mods.factorio.com/mods/Earendel/aai-vehicles-warden)
[AAI Zones](https://mods.factorio.com/mods/Earendel/aai-zones)