require("config")

require("prototypes.recipe-updates")