# Geothermal
Adds geothermal power.
-----------------
Primary Features:
Geothermal patches spawn in the world
Geothermal wells and heat exchangers to convert superheated water to steam

Secondary Features:
Advanced Geothermal research also unlocks the steam turbine (nuclear power still does as well)
Integration with AlienBiomes; if installed, geothermal patches only spawn in volcanic regions, but are much more common there