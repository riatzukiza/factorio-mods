require "config"

CHUNK_SIZE = 32

PATCH_RATE_FACTOR = 0.25
NONVOLCANIC_FACTOR = 1/24/4

function initModifiers(isInit)

end