require("config")

require("prototypes.turbine")
require("prototypes.well")
require("prototypes.tech")
require("prototypes.fluid")