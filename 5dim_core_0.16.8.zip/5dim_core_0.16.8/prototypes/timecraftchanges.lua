data.raw.recipe["pumpjack"].energy_required = 8
data.raw.recipe["oil-refinery"].energy_required = 8
data.raw.recipe["chemical-plant"].energy_required = 8