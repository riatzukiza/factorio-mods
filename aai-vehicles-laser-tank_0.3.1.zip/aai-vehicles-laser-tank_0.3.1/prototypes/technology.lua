data:extend( { {
    type = "technology",
    name = "vehicle-laser-tank",
    icon = "__aai-vehicles-laser-tank__/graphics/technology/laser-tank.png",
    icon_size = 128,
    order = "c-m-a",
    effects = {
        {
            type = "unlock-recipe",
            recipe = "vehicle-laser-tank",
        },
        {
            type = "unlock-recipe",
            recipe = "laser-cannon-battery-piercing",
        },
        {
            type = "unlock-recipe",
            recipe = "laser-cannon-battery-focussed",
        }
    },
    prerequisites = {"tanks", "laser-turrets"},
    unit = {
        count = 100,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
        },
        time = 10
    },
}, } )

--[[
if data.raw["technology"]["tanks"] then
	table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "vehicle-laser-tank"})
	table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "laser-cannon-battery-piercing"})
	table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "laser-cannon-battery-focussed"})
end]]--

local i = 1
while data.raw["technology"]["laser-turret-damage-"..i] do
	local tech = data.raw["technology"]["laser-turret-damage-"..i]
	if tech.effects then
		for _, effect in pairs(tech.effects) do
			if effect.type == "ammo-damage" and effect.ammo_category == "laser-turret" then
				table.insert(tech.effects,
				{
					type = "ammo-damage",
					ammo_category = "laser-cannon",
					modifier = effect.modifier
				})
			end
		end
	end
	i = i + 1
end
