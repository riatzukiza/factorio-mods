if not onlysmelting then onlysmelting = {} end
--if not onlysmelting.config then onlysmelting.config = {

--EquipmentInChest = true

--}
--end
