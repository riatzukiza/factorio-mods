 -- advanced accumulator
require("prototypes.entity.advanced-accumulator")
require("prototypes.item.advanced-accumulator")
require("prototypes.crafting.advanced-accumulator")
require("prototypes.technology.advanced-accumulator")
 -- elite accumulator
require("prototypes.entity.elite-accumulator")
require("prototypes.item.elite-accumulator")
require("prototypes.crafting.elite-accumulator")
require("prototypes.technology.elite-accumulator")
 -- advanced solar
require("prototypes.entity.advanced-solar")
require("prototypes.item.advanced-solar")
require("prototypes.crafting.advanced-solar")
require("prototypes.technology.advanced-solar")
 -- elite solar
require("prototypes.entity.elite-solar")
require("prototypes.item.elite-solar")
require("prototypes.crafting.elite-solar")
require("prototypes.technology.elite-solar") 
