data:extend(
{
  {
    type = "recipe",
    name = "elite-accumulator",
    energy_required = 62,
    enabled = "false",
    ingredients =
    {
      {"advanced-accumulator", 5},
      {"iron-plate", 10},
      {"advanced-circuit", 2},
      {"battery", 10}
    },
    result = "elite-accumulator"
  }
}
)
