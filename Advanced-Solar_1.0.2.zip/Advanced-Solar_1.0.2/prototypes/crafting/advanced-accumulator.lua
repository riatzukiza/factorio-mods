data:extend(
{
  {
    type = "recipe",
    name = "advanced-accumulator",
    energy_required = 25,
    enabled = "false",
    ingredients =
    {
      {"accumulator", 5},
      {"iron-plate", 5},
      {"electronic-circuit", 2},
      {"battery", 5}
    },
    result = "advanced-accumulator"
  }
}
)
