data:extend(
{
  {
    type = "recipe",
    name = "advanced-solar",
    energy_required = 25,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 10},
      {"electronic-circuit", 15},
      {"copper-plate", 10},
      {"solar-panel", 5}
    },
    result = "advanced-solar"
  }
}
)
