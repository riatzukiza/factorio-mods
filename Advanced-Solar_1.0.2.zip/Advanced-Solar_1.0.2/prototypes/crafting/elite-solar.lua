data:extend(
{
  {
    type = "recipe",
    name = "elite-solar",
    energy_required = 62,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 10},
      {"productivity-module", 1},
      {"advanced-solar", 5}
    },
    result = "elite-solar"
  }
}
)
