--Define if battlefield is installed
battlefield = true --Default: True