if settings.startup["af-use-powerbar-icons"].value == true then
    if data.raw.item["air-filter-machine-mk1"] then data.raw.item["air-filter-machine-mk1"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk1-PB.png" end
    if data.raw.recipe["air-filter-machine-mk1"] then data.raw.recipe["air-filter-machine-mk1"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk1-PB.png" end
    if data.raw.item["air-filter-machine-mk2"] then data.raw.item["air-filter-machine-mk2"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk2-PB.png" end
    if data.raw.recipe["air-filter-machine-mk2"] then data.raw.recipe["air-filter-machine-mk2"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk2-PB.png" end
    if data.raw.item["air-filter-machine-mk3"] then data.raw.item["air-filter-machine-mk3"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk3-PB.png" end
    if data.raw.recipe["air-filter-machine-mk3"] then data.raw.recipe["air-filter-machine-mk3"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk3-PB.png" end
    if data.raw.item["air-filter-machine-mk4"] then data.raw.item["air-filter-machine-mk4"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk4-PB.png" end
    if data.raw.recipe["air-filter-machine-mk4"] then data.raw.recipe["air-filter-machine-mk4"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk4-PB.png" end
    if data.raw.item["air-filter-machine-mk5"] then data.raw.item["air-filter-machine-mk5"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk5-PB.png" end
    if data.raw.recipe["air-filter-machine-mk5"] then data.raw.recipe["air-filter-machine-mk5"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk5-PB.png" end
    if data.raw.item["air-filter-machine-mk6"] then data.raw.item["air-filter-machine-mk6"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk6-PB.png" end
    if data.raw.recipe["air-filter-machine-mk6"] then data.raw.recipe["air-filter-machine-mk6"].icon = "__air-filtering-patched__/graphics/icons/air-filter-machine-mk6-PB.png" end
end
