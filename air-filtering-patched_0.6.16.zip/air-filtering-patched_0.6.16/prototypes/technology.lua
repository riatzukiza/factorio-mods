data:extend({
  {
    type = "technology",
    name = "air-filtering",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk1.png",
    icon_size = "64",
    prerequisites = {"plastics", "steel-processing", "electronics", "automation"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk1"
      },
      {
        type = "unlock-recipe",
        recipe = "filter-air"
      },
      {
        type = "unlock-recipe",
        recipe = "unused-air-filter"
      }
    },
    unit =
    {
      count = 150,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 30
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filtering-mk2",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk2.png",
    icon_size = "64",
    prerequisites = {"air-filtering", "automation-2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk2"
      }
    },
    unit =
    {
      count = 300,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 60
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filtering-mk3",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk3.png",
    icon_size = "64",
    prerequisites = {"air-filtering-mk2", "automation-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk3"
      }
    },
    unit =
    {
      count = 500,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 2},
        {"production-science-pack", 1}
      },
      time = 60
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filtering-mk4",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk4.png",
    icon_size = "64",
    prerequisites = {"air-filtering-mk3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk4"
      }
    },
    unit =
    {
      count = 500,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 2},
        {"production-science-pack", 2}
      },
      time = 75
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filtering-mk5",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk5.png",
    icon_size = "64",
    prerequisites = {"air-filtering-mk4"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk5"
      }
    },
    unit =
    {
      count = 2000,
      ingredients = {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2},
        {"production-science-pack", 2},
		{"high-tech-science-pack", 1}
      },
      time = 90
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filtering-mk6",
    icon = "__air-filtering-patched__/graphics/technology/air-filtering-mk6.png",
    icon_size = "64",
    prerequisites = {"air-filtering-mk5"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-machine-mk6"
      }
    },
    unit =
    {
      count = 2500,
      ingredients = {
        {"science-pack-1", 5},
        {"science-pack-2", 5},
        {"science-pack-3", 5},
        {"production-science-pack", 3},
		{"high-tech-science-pack", 2},
		{"space-science-pack", 1}
      },
      time = 180
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "air-filter-recycling",
    icon = "__air-filtering-patched__/graphics/technology/air-filter-recycling.png",
    icon_size = "64",
    prerequisites = {"air-filtering"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "air-filter-recycling"
      }
    },
    unit =
    {
      count = 150,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "d-a-a"
  },
  {
    type = "technology",
    name = "advanced-air-filter-recycling",
    icon = "__air-filtering-patched__/graphics/technology/advanced-air-filter-recycling.png",
    icon_size = "64",
    prerequisites = {"air-filter-recycling"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-air-filter-recycling"
      }
    },
    unit =
    {
      count = 500,
      ingredients = {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 2},
        {"production-science-pack", 1}
      },
      time = 90
    },
    order = "d-a-a"
  }
})
