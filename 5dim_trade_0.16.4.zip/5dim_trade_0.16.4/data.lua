require("config")
--Recipe Trades
require("prototypes.trader-recipes")
--Trader
require("prototypes.trader")
--Recipe
require("prototypes.recipe-category")
--Tech
require("prototypes.tech")
