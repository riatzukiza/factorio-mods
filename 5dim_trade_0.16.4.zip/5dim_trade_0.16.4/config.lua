--Define if resources is installed
trader = true --Default: True